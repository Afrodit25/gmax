
function getPreloadImages( conf, slotConf, winLines, lang, jackpotType ) {
//	var images = getPreloadImagesCommon( conf, 'fruitmania', true );
	var images = getPreloadImagesCommon( { 
		conf : conf,
		slotConf: slotConf,
		folder: 'fruitmania',
		winLines: winLines,
		noCoinShower: true,
		bigWinFrames: false,
		jackpotType: jackpotType,
		lang: lang
	});
	// ####
	
	if( jackpotType == 'firepot' ) {
		images.push( 'gui/picts/game/1280/firepot/logo.png' );
	}
	
	if( conf.mode( 'c') == 0 ) { // web 
		var conImages = [
			// info sites
			'gui/picts/rest/fruitmania/<resol>/infoSites/web/background.png',
			'gui/picts/rest/fruitmania/<resol>/infoSites/web/button-close.png',
			'gui/picts/rest/fruitmania/<resol>/infoSites/web/checkbox-off.png',
			'gui/picts/rest/fruitmania/<resol>/infoSites/web/checkbox-on.png',
		];
		
		images = images.concat( conImages );
	}
	else { // mobile
		var conImages = [
		];
		
		images = images.concat( conImages );
		
		if( conf.mode( 'c' ) == 2 ) { // supporting portrait mode
			var portConImages = [			
			    'gui/picts/rest/fruitmania/<resol>/portrait_bottom_l169.jpg',
				'gui/picts/rest/fruitmania/<resol>/portrait_bottom_l32.jpg',
				'gui/picts/rest/fruitmania/<resol>/portrait_top.jpg',
				'gui/picts/rest/fruitmania/<resol>/portrait_top_small.jpg'
			];
			images = images.concat( portConImages );
		}
	}
	
	// ####
	var common = [
		// backgrounds
		'gui/picts/rest/fruitmania/<resol>/bg_middle.jpg',
    	'gui/picts/rest/fruitmania/<resol>/bg_bottom.jpg',
    	'gui/picts/rest/fruitmania/<resol>/fadeout.png',
    	
		// linemarkers
		'gui/picts/game/<resol>/linemarker/line-number-1.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-2.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-3.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-4.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-5.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-grey.jpg',
		'gui/picts/game/<resol>/linemarker/line-number-dimm.png',
		
		// info sites
		'gui/picts/rest/fruitmania/<resol>/infoSites/7.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/glocke.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/kirsche.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/lines.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/melone.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/orange.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/traube.png',
		'gui/picts/rest/fruitmania/<resol>/infoSites/zitrone.png',
		
		// symbols
		[ '/symbol-bell.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-bell.jpg' ],
		[ '/symbol-bell1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-bell1.png' ],
		[ '/symbol-bell2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-bell2.png' ],
		[ '/symbol-cherry.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-cherry.jpg' ],
		[ '/symbol-cherry1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-cherry1.png' ],
		[ '/symbol-cherry2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-cherry2.png' ],
		[ '/symbol-grapes.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-grapes.jpg' ],
		[ '/symbol-grapes1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-grapes1.png' ],
		[ '/symbol-grapes2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-grapes2.png' ],
		[ '/symbol-lemon.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-lemon.jpg' ],
		[ '/symbol-lemon1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-lemon1.png' ],
		[ '/symbol-lemon2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-lemon2.png' ],
		[ '/symbol-melon.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-melon.jpg' ],
		[ '/symbol-melon1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-melon1.png' ],
		[ '/symbol-melon2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-melon2.png' ],
		[ '/symbol-orange.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-orange.jpg' ],
		[ '/symbol-orange1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-orange1.png' ],
		[ '/symbol-orange2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-orange2.png' ],
		[ '/symbol-seven.jpg', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-seven.jpg' ],
		[ '/symbol-seven1.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-seven1.png' ],
		[ '/symbol-seven2.png', 'gui/picts/rest/fruitmania/<resol>/symbols/symbol-seven2.png' ],
		
	];
	images = images.concat( common );

	if( conf.playSymbolAnims() ) {
		var rImages = [
	           // symbol anims
	           [ 'bigWin_0.jpg', 'gui/picts/rest/fruitmania/<resol>/symanim/bigWin_0.jpg' ]
           ];
		images = images.concat( rImages );
	}
	else{
		var oImages = [
		       // optimal slot animations	
	    		[ 'BWx1', 'gui/picts/blank.gif' ],
	    		[ 'BWx1Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx2', 'gui/picts/blank.gif' ],
	    		[ 'BWx2Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx3', 'gui/picts/blank.gif' ],
	    		[ 'BWx3Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx4', 'gui/picts/blank.gif' ],
	    		[ 'BWx4Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx5', 'gui/picts/blank.gif' ],
	    		[ 'BWx5Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx6', 'gui/picts/blank.gif' ],
	    		[ 'BWx6Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
	    		[ 'BWx7', 'gui/picts/blank.gif' ],
	    		[ 'BWx7Glow', 'gui/picts/rest/fruitmania/<resol>/optanim/WinAni_OptimalSlot_Frame.png' ],
           ];
		images = images.concat( oImages );
		
	}
	return images;
}
